import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

function Residents() {
  const navigate = useNavigate();

  const [residents, setResidents] = useState([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("All");

  useEffect(() => {
    fetchResidents();
  }, []);

  const fetchResidents = async () => {
    try {
      const response = await axios.get(
        "http://localhost:5000/api/residents"
      );

      setResidents(response.data.data);
    } catch (error) {
      console.error("Error fetching residents:", error);
    }
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Residents List</h1>

      <button
        onClick={() => navigate("/add-resident")}
        style={{
          backgroundColor: "#28a745",
          color: "white",
          padding: "10px 20px",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer",
          marginBottom: "20px",
          marginRight: "20px",
        }}
      >
        ➕ Add Resident
      </button>

      <div
        style={{
          display: "flex",
          gap: "15px",
          marginBottom: "20px",
          alignItems: "center",
        }}
      >
        <input
          type="text"
          placeholder="🔍 Search by Name"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          style={{
            padding: "10px",
            width: "250px",
            borderRadius: "8px",
            border: "1px solid #ccc",
          }}
        />

        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          style={{
            padding: "10px",
            borderRadius: "8px",
          }}
        >
          <option value="All">All</option>
          <option value="Stable">Stable</option>
          <option value="Critical">Critical</option>
          <option value="Under Observation">
            Under Observation
          </option>
        </select>
      </div>

      <table
        border="1"
        cellPadding="10"
        style={{
          width: "100%",
          borderCollapse: "collapse",
        }}
      >
        <thead>
          <tr>
            <th>Name</th>
            <th>Age</th>
            <th>Gender</th>
            <th>Blood Group</th>
            <th>Phone</th>
            <th>Health Status</th>
            <th>Action</th>
          </tr>
        </thead>

        <tbody>
          {residents
            .filter((resident) => {
              const matchesSearch = resident.fullName
                .toLowerCase()
                .includes(search.toLowerCase());

              const matchesFilter =
                filter === "All" ||
                resident.healthStatus === filter;

              return matchesSearch && matchesFilter;
            })
            .map((resident) => (
              <tr key={resident._id}>
                <td>{resident.fullName}</td>
                <td>{resident.age}</td>
                <td>{resident.gender}</td>
                <td>{resident.bloodGroup}</td>
                <td>{resident.phone}</td>
                <td>{resident.healthStatus}</td>

                <td>
                  <button
                    onClick={() =>
                      navigate(`/edit-resident/${resident._id}`)
                    }
                    style={{
                      background: "#007bff",
                      color: "white",
                      border: "none",
                      padding: "6px 12px",
                      borderRadius: "5px",
                      cursor: "pointer",
                    }}
                  >
                    Edit
                  </button>
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

export default Residents;