import { useState } from "react";

function Settings() {
  const [admin, setAdmin] = useState({
    name: "Administrator",
    email: "admin@seniorcare.com",
    phone: "9876543210",
  });

  return (
    <div style={{ padding: "30px" }}>
      <h1>⚙️ Settings</h1>

      <div style={{
        width: "450px",
        background: "#fff",
        padding: "20px",
        borderRadius: "10px",
        boxShadow: "0 0 10px rgba(0,0,0,0.2)"
      }}>

        <h2>Admin Profile</h2>

        <p><b>Name:</b> {admin.name}</p>

        <p><b>Email:</b> {admin.email}</p>

        <p><b>Phone:</b> {admin.phone}</p>

        <button style={{
          padding: "10px 20px",
          background: "#8B5E3C",
          color: "white",
          border: "none",
          borderRadius: "5px",
          cursor: "pointer"
        }}>
          Change Password
        </button>

      </div>
    </div>
  );
}

export default Settings;