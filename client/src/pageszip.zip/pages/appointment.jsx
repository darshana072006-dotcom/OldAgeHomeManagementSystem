import { useState } from "react";

function Appointment() {
  const [appointment, setAppointment] = useState({
    residentId: "",
    doctorName: "",
    appointmentDate: "",
    appointmentTime: "",
    hospital: "",
    purpose: "",
  });

  const handleChange = (e) => {
    setAppointment({
      ...appointment,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    alert("Appointment Added Successfully!");

    console.log(appointment);

    setAppointment({
      residentId: "",
      doctorName: "",
      appointmentDate: "",
      appointmentTime: "",
      hospital: "",
      purpose: "",
    });
  };

  return (
    <div style={{ padding: "30px" }}>
      <h1>Appointment Management</h1>

      <form onSubmit={handleSubmit}>
        <input
          type="text"
          name="residentId"
          placeholder="Resident ID"
          value={appointment.residentId}
          onChange={handleChange}
        />
        <br /><br />

        <input
          type="text"
          name="doctorName"
          placeholder="Doctor Name"
          value={appointment.doctorName}
          onChange={handleChange}
        />
        <br /><br />

        <input
          type="date"
          name="appointmentDate"
          value={appointment.appointmentDate}
          onChange={handleChange}
        />
        <br /><br />

        <input
          type="time"
          name="appointmentTime"
          value={appointment.appointmentTime}
          onChange={handleChange}
        />
        <br /><br />

        <input
          type="text"
          name="hospital"
          placeholder="Hospital"
          value={appointment.hospital}
          onChange={handleChange}
        />
        <br /><br />

        <input
          type="text"
          name="purpose"
          placeholder="Purpose"
          value={appointment.purpose}
          onChange={handleChange}
        />
        <br /><br />

        <button type="submit">
          Save Appointment
        </button>
      </form>
    </div>
  );
}

export default Appointment;