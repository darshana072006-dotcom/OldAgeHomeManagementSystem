const express = require("express");
const router = express.Router();

const {
  addAppointment,
  getAppointments,
} = require("../controllers/appointmentController");

router.get("/", getAppointments);
router.post("/", addAppointment);

module.exports = router;