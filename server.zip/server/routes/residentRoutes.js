const express = require("express");
const router = express.Router();

const {
  addResident,
  getResidents,
  getResidentById,
  updateResident,
  deleteResident,
} = require("../controllers/residentController");

// Get all residents
router.get("/", getResidents);

// Get one resident
router.get("/:id", getResidentById);

// Add resident
router.post("/", addResident);

// Update resident
router.put("/:id", updateResident);

// Delete resident
router.delete("/:id", deleteResident);

module.exports = router;